from plcEdu import *

reading = din()
print("Reading: %s"%reading)


