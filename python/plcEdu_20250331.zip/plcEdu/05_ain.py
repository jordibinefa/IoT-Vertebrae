from plcEdu import *

canal = 4
aVal = ain(canal)
print("Reading ",aVal," volts at canal ",canal)
